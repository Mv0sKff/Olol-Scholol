import os

os.system("zip -r olol-scholol.zip * -x \"*.zip\"")